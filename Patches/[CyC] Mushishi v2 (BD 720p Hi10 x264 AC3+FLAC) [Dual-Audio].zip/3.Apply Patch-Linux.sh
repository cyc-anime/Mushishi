` #!/bin/sh`
` mkdir old`
` chmod +x xdelta3`
` xdelta3 -v -d -s "[CyC] Mushishi 01 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [E534B31E].mkv" "vcdiff/[CyC] Mushishi 01 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [E534B31E].mkv.vcdiff" "[CyC] Mushishi 01v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [343761E3].mkv"`
` mv "[CyC] Mushishi 01 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [E534B31E].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 02 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [AD4AA03A].mkv" "vcdiff/[CyC] Mushishi 02 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [AD4AA03A].mkv.vcdiff" "[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5A752623].mkv"`
` mv "[CyC] Mushishi 02 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [AD4AA03A].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 03 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [491383BD].mkv" "vcdiff/[CyC] Mushishi 03 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [491383BD].mkv.vcdiff" "[CyC] Mushishi 03v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [71E59744].mkv"`
` mv "[CyC] Mushishi 03 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [491383BD].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 04 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [CA4EB0AD].mkv" "vcdiff/[CyC] Mushishi 04 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [CA4EB0AD].mkv.vcdiff" "[CyC] Mushishi 04v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [8B117BE6].mkv"`
` mv "[CyC] Mushishi 04 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [CA4EB0AD].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 05 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [EF6B8070].mkv" "vcdiff/[CyC] Mushishi 05 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [EF6B8070].mkv.vcdiff" "[CyC] Mushishi 05v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [7FDC8047].mkv"`
` mv "[CyC] Mushishi 05 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [EF6B8070].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 06 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [2B70CA1F].mkv" "vcdiff/[CyC] Mushishi 06 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [2B70CA1F].mkv.vcdiff" "[CyC] Mushishi 06v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [AC979D66].mkv"`
` mv "[CyC] Mushishi 06 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [2B70CA1F].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 07 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3F3DD4CE].mkv" "vcdiff/[CyC] Mushishi 07 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3F3DD4CE].mkv.vcdiff" "[CyC] Mushishi 07v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F4400A2A].mkv"`
` mv "[CyC] Mushishi 07 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3F3DD4CE].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 08 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A0BB5FC4].mkv" "vcdiff/[CyC] Mushishi 08 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A0BB5FC4].mkv.vcdiff" "[CyC] Mushishi 08v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [7C17A7F9].mkv"`
` mv "[CyC] Mushishi 08 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A0BB5FC4].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 09 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [C397BF64].mkv" "vcdiff/[CyC] Mushishi 09 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [C397BF64].mkv.vcdiff" "[CyC] Mushishi 09v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D56A0022].mkv"`
` mv "[CyC] Mushishi 09 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [C397BF64].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 10 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [1D2A9257].mkv" "vcdiff/[CyC] Mushishi 10 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [1D2A9257].mkv.vcdiff" "[CyC] Mushishi 10v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [E907502B].mkv"`
` mv "[CyC] Mushishi 10 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [1D2A9257].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 11 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [B1030A22].mkv" "vcdiff/[CyC] Mushishi 11 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [B1030A22].mkv.vcdiff" "[CyC] Mushishi 11v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [CE005C04].mkv"`
` mv "[CyC] Mushishi 11 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [B1030A22].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 12 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [680618FA].mkv" "vcdiff/[CyC] Mushishi 12 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [680618FA].mkv.vcdiff" "[CyC] Mushishi 12v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0BF14F61].mkv"`
` mv "[CyC] Mushishi 12 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [680618FA].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 13 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F2445863].mkv" "vcdiff/[CyC] Mushishi 13 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F2445863].mkv.vcdiff" "[CyC] Mushishi 13v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [34D06D9E].mkv"`
` mv "[CyC] Mushishi 13 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F2445863].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 14 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5AABF327].mkv" "vcdiff/[CyC] Mushishi 14 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5AABF327].mkv.vcdiff" "[CyC] Mushishi 14v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [10D729C3].mkv"`
` mv "[CyC] Mushishi 14 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5AABF327].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 15 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5CDF9390].mkv" "vcdiff/[CyC] Mushishi 15 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5CDF9390].mkv.vcdiff" "[CyC] Mushishi 15v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [FF0BF3CE].mkv"`
` mv "[CyC] Mushishi 15 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5CDF9390].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 16 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0D0A63A8].mkv" "vcdiff/[CyC] Mushishi 16 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0D0A63A8].mkv.vcdiff" "[CyC] Mushishi 16v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [CD29C55C].mkv"`
` mv "[CyC] Mushishi 16 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0D0A63A8].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 17 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [18CC8549].mkv" "vcdiff/[CyC] Mushishi 17 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [18CC8549].mkv.vcdiff" "[CyC] Mushishi 17v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [8E774158].mkv"`
` mv "[CyC] Mushishi 17 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [18CC8549].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 18 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A4D76A5E].mkv" "vcdiff/[CyC] Mushishi 18 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A4D76A5E].mkv.vcdiff" "[CyC] Mushishi 18v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0F934121].mkv"`
` mv "[CyC] Mushishi 18 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A4D76A5E].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 19 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4FBAFBE3].mkv" "vcdiff/[CyC] Mushishi 19 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4FBAFBE3].mkv.vcdiff" "[CyC] Mushishi 19v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3A522058].mkv"`
` mv "[CyC] Mushishi 19 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4FBAFBE3].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 20 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [64EEF606].mkv" "vcdiff/[CyC] Mushishi 20 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [64EEF606].mkv.vcdiff" "[CyC] Mushishi 20v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [68005B43].mkv"`
` mv "[CyC] Mushishi 20 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [64EEF606].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 21 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D232092B].mkv" "vcdiff/[CyC] Mushishi 21 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D232092B].mkv.vcdiff" "[CyC] Mushishi 21v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [14F1AB71].mkv"`
` mv "[CyC] Mushishi 21 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D232092B].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 22 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F7BE23E3].mkv" "vcdiff/[CyC] Mushishi 22 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F7BE23E3].mkv.vcdiff" "[CyC] Mushishi 22v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [EC7C55BE].mkv"`
` mv "[CyC] Mushishi 22 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [F7BE23E3].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 23 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3F82867D].mkv" "vcdiff/[CyC] Mushishi 23 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3F82867D].mkv.vcdiff" "[CyC] Mushishi 23v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [BAC5B46F].mkv"`
` mv "[CyC] Mushishi 23 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [3F82867D].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 24 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [2100B661].mkv" "vcdiff/[CyC] Mushishi 24 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [2100B661].mkv.vcdiff" "[CyC] Mushishi 24v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [C79977C5].mkv"`
` mv "[CyC] Mushishi 24 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [2100B661].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 25 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A62D4111].mkv" "vcdiff/[CyC] Mushishi 25 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A62D4111].mkv.vcdiff" "[CyC] Mushishi 25v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [35497899].mkv"`
` mv "[CyC] Mushishi 25 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A62D4111].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 26 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [FBB9D177].mkv" "vcdiff/[CyC] Mushishi 26 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [FBB9D177].mkv.vcdiff" "[CyC] Mushishi 26v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [DA6373F0].mkv"`
` mv "[CyC] Mushishi 26 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [FBB9D177].mkv" old`
