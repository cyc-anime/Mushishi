` #!/bin/sh`
` mkdir old`
` chmod +x xdelta3`
` xdelta3 -v -d -s "[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5A752623].mkv" "vcdiff/[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5A752623].mkv.vcdiff" "[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4E106823].mkv"`
` mv "[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [5A752623].mkv" old`
