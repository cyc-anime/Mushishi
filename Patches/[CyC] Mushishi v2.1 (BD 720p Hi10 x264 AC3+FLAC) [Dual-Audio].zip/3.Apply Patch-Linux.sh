` #!/bin/sh`
` mkdir old`
` chmod +x xdelta3`
` xdelta3 -v -d -s "[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4E106823].mkv" "vcdiff/[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4E106823].mkv.vcdiff" "[CyC] Mushishi 02v2.1 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [087A63BC].mkv"`
` mv "[CyC] Mushishi 02v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4E106823].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 03v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [71E59744].mkv" "vcdiff/[CyC] Mushishi 03v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [71E59744].mkv.vcdiff" "[CyC] Mushishi 03v2.1 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A66B65B3].mkv"`
` mv "[CyC] Mushishi 03v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [71E59744].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 09v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D56A0022].mkv" "vcdiff/[CyC] Mushishi 09v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D56A0022].mkv.vcdiff" "[CyC] Mushishi 09v2.1 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [A7450DB7].mkv"`
` mv "[CyC] Mushishi 09v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [D56A0022].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 12v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0BF14F61].mkv" "vcdiff/[CyC] Mushishi 12v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0BF14F61].mkv.vcdiff" "[CyC] Mushishi 12v2.1 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [52786A01].mkv"`
` mv "[CyC] Mushishi 12v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [0BF14F61].mkv" old`
` xdelta3 -v -d -s "[CyC] Mushishi 14v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [10D729C3].mkv" "vcdiff/[CyC] Mushishi 14v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [10D729C3].mkv.vcdiff" "[CyC] Mushishi 14v2.1 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [4E529F26].mkv"`
` mv "[CyC] Mushishi 14v2 (BD 720p Hi10 x264 AC3+FLAC) [Dual-Audio] [10D729C3].mkv" old`
